/* ===== ADET ARTTIR / AZALT ===== */
function AdetArtirma(id){
  const i = document.getElementById(id);
  if(Number(i.value) < 10) i.value++;
}

function AdetAzaltma(id){
  const i = document.getElementById(id);
  if(Number(i.value) > 1) i.value--;
}

/* ===== SEPET ===== */
let sepet = JSON.parse(localStorage.getItem("sepet")) || [];

document.addEventListener("click", e => {

  if(!e.target.classList.contains("sepete-ekle")) return;

  const b = e.target;
  const adet = Number(document.getElementById(b.dataset.input).value);

  const urun = {
    id: b.dataset.id,
    ad: b.dataset.ad,
    aciklama: b.dataset.aciklama,
    fiyat: Number(b.dataset.fiyat),
    img: b.dataset.img,
    adet: adet
  };

  const idx = sepet.findIndex(u => u.id === urun.id);
  if(idx >= 0) sepet[idx].adet = urun.adet;
  else sepet.push(urun);

  localStorage.setItem("sepet", JSON.stringify(sepet));
  popupGoster();
});

/* ===== POPUP ===== */
function popupGoster(){

  let p = document.getElementById("sepetPopup");
  if(p) p.remove();

  p = document.createElement("div");
  p.id = "sepetPopup";
  p.style.cssText = `
    position:absolute;
    top:65px;
    right:20px;
    width:300px;
    background:#ABD0C6;
    padding:10px;
    border-radius:10px;
    z-index:9999;
  `;

  let toplam = 0;

  sepet.forEach((u,i)=>{
    toplam += u.adet * u.fiyat;
    p.innerHTML += `
      <div style="display:flex;gap:10px;margin-bottom:8px">
        <img src="${u.img}" style="width:50px;height:50px;border-radius:6px">
        <div>
          <b>${u.ad}</b><br>
          <small>${u.aciklama}</small><br>
          <button onclick="degistir(${i},-1)">-</button>
          ${u.adet}
          <button onclick="degistir(${i},1)">+</button>
        </div>
      </div>
    `;
  });

  p.innerHTML += `<hr><b>Toplam: ${toplam} TL</b>
  <br><br><button onclick="location.href='sepetim.html'">Sepete Git</button>`;

  document.body.appendChild(p);
}

function degistir(i,d){
  sepet[i].adet += d;
  if(sepet[i].adet <= 0) sepet.splice(i,1);
  if(sepet[i]?.adet > 10) sepet[i].adet = 10;
  localStorage.setItem("sepet",JSON.stringify(sepet));
  popupGoster();
}
